# Change Background Color

A Pen created on CodePen.io. Original URL: [https://codepen.io/Josefr83/pen/abRWyvK](https://codepen.io/Josefr83/pen/abRWyvK).

