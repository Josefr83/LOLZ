document.getElementById('changeColorBtn').addEventListener('click', () => {
    const randomColor = () => {
        return Math.floor(Math.random() * 256);
    };
    const newColor = `rgb(${randomColor()}, ${randomColor()}, ${randomColor()})`;
    document.body.style.backgroundColor = newColor;
});

